# Changelog — Minecraft Companion 0.9.7.1

## 0.9.7.1-dev.11 candidate — vanilla Companion swing lifecycle

- Fixed the proven client swing divergence. `CompanionEntity` extends `PathAwareEntity`, while the exact Minecraft 1.20.1 Yarn build.10 vanilla caller is `HostileEntity.tickMovement()`. The tracked Companion received the animation packet but its hierarchy never advanced `tickHandSwing()`.
- Added a `tickMovement()` override that invokes inherited vanilla `tickHandSwing()` once before delegating to `PathAwareEntity`, preserving vanilla ordering and leaving renderer/model code unchanged.
- Added server lifecycle coverage for requested hand, vanilla progress, and completion. The first GameTest callback was too early: vanilla begins at tick -1, advances to 0 with zero progress, then reaches positive progress on a later entity tick. The corrected test observes a bounded window based on vanilla's six-tick duration and verifies release.
- Retained the 300 committed-melee-hit soak; run 72 passed it.
- Run 72 clean build/project checks passed. Its real client owner-defense chain passed, and rendered swing captures contained IDLE, EARLY, MID, LATE, and IDLE_AGAIN for empty hand, Classic sword, and Slim sword. One GameTest timing assertion failed; persistence was skipped. Candidate remains unvalidated pending reruns.
