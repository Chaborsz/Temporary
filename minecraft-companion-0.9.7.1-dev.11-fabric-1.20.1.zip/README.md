# Minecraft Companion 0.9.7.1 — dev.11 candidate

Minecraft 1.20.1 · Fabric · Java 17

This candidate is based on immutable dev.10. The production fix adds the missing vanilla `tickHandSwing()` lifecycle call to `CompanionEntity.tickMovement()`, matching the exact Yarn 1.20.1 build.10 `HostileEntity.tickMovement()` ordering. The real-client swing sequence was captured in run 72; a dedicated-server GameTest timing assumption was corrected separately. This is not Stable until the full exact-source regression gates pass.
