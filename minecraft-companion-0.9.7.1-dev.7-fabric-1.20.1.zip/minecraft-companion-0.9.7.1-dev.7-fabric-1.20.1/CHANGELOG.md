# 0.9.7.1-dev.7 release candidate

- Sets Gradle/Fabric project version to 0.9.7.1 for stable release identity.
- No gameplay, rendering, persistence, or UI code changes from immutable dev.6.
- Requires exact-source full validation before Stable release.
