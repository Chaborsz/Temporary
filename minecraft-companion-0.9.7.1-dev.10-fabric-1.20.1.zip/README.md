# Minecraft Companion 0.9.7.1-dev.10

Diagnostic candidate based on immutable dev.9. It logs real idle movement diagnostics from each GameTest run, successful or failed, while preserving the original assertion and production behavior.

Not Stable. Exact-source Gradle, GameTest, persistence, real client, named HUD and visual swing gates are pending. `eula=false` is preserved.
