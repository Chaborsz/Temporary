# 0.9.7.1-dev.8 release candidate

- Corrects the FOLLOW idle-movement GameTest fixture so the ambient roam goal has MOVE control without competing with FollowOwnerGoal.
- Preserves the real-navigation movement assertion and owner leash check.
- No production gameplay, rendering, persistence, UI, or metadata source changes from immutable dev.7.
- Exact-source full validation remains required before Stable.
