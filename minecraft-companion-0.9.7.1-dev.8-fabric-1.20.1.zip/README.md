# Minecraft Companion 0.9.7.1-dev.8 release candidate

Minecraft 1.20.1 · Fabric · Java 17 · Gradle 8.8 · Loom 1.6.12

This candidate is based on immutable dev.7. It corrects only the FOLLOW idle-movement GameTest fixture; no production code or assertion was changed. Exact-source runtime validation is in progress. This is not Stable.
