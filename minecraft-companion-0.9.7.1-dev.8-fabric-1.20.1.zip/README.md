# Minecraft Companion 0.9.7.1-dev.8 release candidate

Minecraft 1.20.1 · Fabric · Java 17

This candidate carries the immutable dev.6 source with the project/Fabric metadata version set to `0.9.7.1`. It is not Stable until its exact source archive passes all build, test, persistence, IntegratedServer, visual HUD, and visual swing gates.
