# Minecraft Companion 0.9.7.1-dev.5

Minecraft 1.20.1 Fabric source checkpoint. Stable 0.9.7.1 remains unchanged.

This checkpoint adds a bounded deterministic fallback to ambient idle destination selection after random candidates fail, while preserving safe-surface, owner-leash, and guard-radius constraints.

Build target: Java 17, Gradle 8.8, Fabric Loom 1.6.12.
