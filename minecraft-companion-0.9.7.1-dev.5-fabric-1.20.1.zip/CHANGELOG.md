# Minecraft Companion 0.9.7.1 development changelog

## 0.9.7.1-dev.5

- Added a bounded deterministic fallback for safe ambient idle destinations after random candidate rejection.
- Kept the owner leash, guard radius, and existing goal/cooldown behavior.

# Changelog

## 0.9.7.1-dev.1

- El Companion nuevo usa DEFENSIVE por defecto, para reaccionar cuando dañan a su dueño sin exigir una configuración previa.
- Los saves de 0.9.7 con el antiguo PASSIVE por defecto migran a DEFENSIVE. Los saves nuevos almacenan un marcador para conservar elecciones explícitas, incluido PASSIVE.
- El HUD de vida se ancla más alto sobre el Companion y usa las celdas de corazón lleno/medio/vacío del atlas vanilla.
- El modelo vanilla de jugador añade un seguimiento discreto del brazo durante el swing sincronizado.
- Se añaden pruebas de migración NBT, defensa del dueño mediante daño real del ServerPlayer y regresiones de HUD/modelo.
