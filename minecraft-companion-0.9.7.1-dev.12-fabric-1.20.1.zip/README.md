# Minecraft Companion 0.9.7.1 — dev.12 release source

Minecraft 1.20.1 · Fabric · Java 17

This source contains the dev.12 ambient-navigation reliability fix. Runs 75 and 76 validated the implementation with full GameTests, persistence, and real-client owner-defense, swing, and HUD coverage. Run76 used Java 17, Gradle 8.8, and Fabric Loom 1.6.12. Detailed evidence is in `0.9.7.1-FALSE-CONFIDENCE-AUDIT.md`.
