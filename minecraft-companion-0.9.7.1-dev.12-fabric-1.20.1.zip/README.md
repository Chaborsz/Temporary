# Minecraft Companion 0.9.7.1 — release candidate

Minecraft 1.20.1 · Fabric · Java 17

This source project carries the dev.12 ambient-navigation reliability fix. Run75 validated the product source with a clean Gradle 8.8 build, project checks, five complete GameTest passes (165/165 each), two persistence rounds, and real-client owner-defense, swing, and HUD evidence. A documentation-only refresh is being checked against these exact bytes before Stable packaging.
