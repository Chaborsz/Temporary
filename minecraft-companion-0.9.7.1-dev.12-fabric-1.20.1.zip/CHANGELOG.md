# Changelog — Minecraft Companion 0.9.7.1

## 0.9.7.1-dev.11 candidate — vanilla Companion swing lifecycle

- Fixed the proven client swing divergence. `CompanionEntity` extends `PathAwareEntity`, while the exact Minecraft 1.20.1 Yarn build.10 vanilla caller is `HostileEntity.tickMovement()`. The tracked Companion received the animation packet but its hierarchy never advanced `tickHandSwing()`.
- Added a `tickMovement()` override that invokes inherited vanilla `tickHandSwing()` once before delegating to `PathAwareEntity`, preserving vanilla ordering and leaving renderer/model code unchanged.
- Added server lifecycle coverage for requested hand, vanilla progress, and completion. The first GameTest callback was too early: vanilla begins at tick -1, advances to 0 with zero progress, then reaches positive progress on a later entity tick. The corrected test observes a bounded window based on vanilla's six-tick duration and verifies release.
- Retained the 300 committed-melee-hit soak; run 72 passed it.
- Run 72 clean build/project checks passed. Its real client owner-defense chain passed, and rendered swing captures contained IDLE, EARLY, MID, LATE, and IDLE_AGAIN for empty hand, Classic sword, and Slim sword. One GameTest timing assertion failed; persistence was skipped. Candidate remains unvalidated pending reruns.


## 0.9.7.1-dev.12 candidate — bounded ambient navigation timing

- Replaced AmbientIdleGoal's callback-count cooldown with deadlines based on the Companion's entity age, so 60–160 means actual entity ticks regardless of GoalSelector scheduling cadence.
- Ambient candidate acceptance now requires a reachable navigation Path; the computed Path is reused when movement starts. If candidate search or path start fails, the retry is scheduled after ten entity ticks rather than another full ambient interval.
- Retained bounded candidate search, four-block FOLLOW comfort leash, four-block maximum step, STAY look-only behavior, GUARD bounds, and combat/order preemption. Added on-demand diagnostics for canStart calls, deadlines, path candidates/rejections/start failures, and last candidate. Added a 20-companion real-navigation soak with distinct owners and independent entity RNG.
- Corrected the FOLLOW idle GameTest explanation: its three-block fixture is inside FollowOwnerGoal's stop band, so the expected movement is AmbientIdleGoal's. Added timing-policy coverage.
- Run 73: clean build and project checks passed; GameTest pass 1 was 164/164, pass 2 was 163/164 with the nondeterministic idle navigation stall. Real client owner defense and the full visible swing phase matrix passed. Persistence was skipped after the GameTest failure.
- Dev.12 remains a candidate pending targeted soak and full validation.
