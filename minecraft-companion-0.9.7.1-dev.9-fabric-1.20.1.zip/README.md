# Minecraft Companion 0.9.7.1-dev.9

Diagnostic release candidate based on immutable dev.8. It adds visibility into each AmbientIdleGoal start rejection and navigation-start outcome while preserving the original idle movement assertion and all production AI policy.

This checkpoint is not Stable. Exact source build, five GameTest passes, two persistence rounds, real client validation, and the remaining visual gates are pending. eula=false is preserved.
