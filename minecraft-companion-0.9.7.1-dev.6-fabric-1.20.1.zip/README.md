# Minecraft Companion 0.9.7.1-dev.6

Minecraft 1.20.1 · Fabric · Java 17

Frozen source candidate for exact-source validation. dev.5 remains immutable. dev.6 expands owner-defense soak coverage to 200 accepted player damage events and melee coverage to 300 committed attacks without relaxing existing assertions.

Local source validation passes 3,045 directed assertions and structural checks. The required Java 17 / Gradle 8.8 clean build, five complete GameTest passes, persistence, exact-candidate real-client checks and complete swing visual matrix remain pending. This is not Stable.
