# Changelog — 0.9.7.1-dev.6

- Owner-defense soak increased to 200 accepted real ServerPlayer damage events.
- Production melee swing soak increased to 300 committed attacks.
- Added finite tick budgets sized for the longer test cycles; original correctness assertions remain.
- No product runtime source changes from immutable dev.5.
